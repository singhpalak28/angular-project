import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  loginForm: FormGroup;
  captcha: string = this.generateCaptcha();
  captchaError: boolean = false;


  constructor(private fb: FormBuilder, private router: Router, private authService:AuthService){
    this.loginForm = this.fb.group({
      email:['',[Validators.required,Validators.email]],
      password:['',Validators.required],
      captchaInput:['',Validators.required]
    });
  }

  generateCaptcha(): string {
    return Math.random().toString(36).substring(2, 8);
  }
  refreshCaptcha(): void {
    this.captcha = this.generateCaptcha();
  }
  onLogin() {
  const captchaInput = this.loginForm.get('captchaInput')?.value;
  this.captchaError = false;

  if (this.loginForm.invalid) {
    alert('Please fill in all required fields correctly.');
    return;
  }

  if (captchaInput !== this.captcha) {
    this.captchaError = true;
    this.refreshCaptcha();
    return;
  }

  // If all good
  this.authService.login();
  this.router.navigate(['/']);
}
}
