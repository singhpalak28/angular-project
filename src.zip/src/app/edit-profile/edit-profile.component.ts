import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {
  profileForm!: FormGroup;

  cityList: string[] = ["Banglore", "Chennai", "Hyderbad", "Mumbai"]

  filteredCities: string[] = [];

  constructor(private fb: FormBuilder, private router: Router) { }

  ngOnInit(): void {
    this.profileForm = this.fb.group({
      name: ['Palak Sharma', [Validators.required, Validators.minLength(3)]],
      email: [{ value: 'palak@example.com', disabled: true }],
      phone: [{ value: '+91-678905432', disabled: true }],
      city: ['Delhi', [Validators.required, this.cityValidator.bind(this)]]
     
    });
    this.profileForm.get('city')?.valueChanges.subscribe(value =>{
      const serachTerm=value.toLowerCase();
      this.filteredCities = this.cityList.filter(city =>city.toLowerCase().includes(serachTerm));
    })
  }
  cityValidator(control:AbstractControl):ValidationErrors | null{
    const inputCity = control.value?.toLowerCase();
    const isValid = this.cityList.some(city => city.toLowerCase() === inputCity);
    return isValid ? null : {
      invalidCity: true
    };
  }
  changePassword(): void {
    this.router.navigate(['/forgetpassword']);// when integrated will be directed to reset password page
  }
  onSubmit() {
    if (this.profileForm.valid) {
      console.log('Updated Profile:', this.profileForm.getRawValue());
      this.router.navigate(['/profile']);
    }
  }
}
